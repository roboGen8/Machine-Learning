This folder contains codes for supervised learning algorithms: 
decision tree
neural networks
boosting 
support vector machines
k-nearest neighbors

There are 10 python files because 2 datasets for each algorithm

The two datasets are mushroom and pulsar star datasets from Kaggle

to run the code just type: python filename

I used Python 2.7 and you need to have scikit-learn
and download other dependencies: pandas, Matplotlib, sklearn, numpy
You can download them by typing in command prompt: pip install (dependency) 

If it doesn't work, run the file through anaconda environment maybe Spyder



